var auto_refresh = setInterval(
function()
{
$('#refreshdiv_serverresources').load('/webapp/engine/resources.php #container');
}, 50000);
