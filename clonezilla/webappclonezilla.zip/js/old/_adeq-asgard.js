$(document).ready(function() {
$("#showPartimag").click(function() {
$('#loader').css ('display' , 'inline');
$('#loader').load('bcs/');
$("#linkAltera1").click(function() {
$("#loader").css('display' , 'none');
});
});
});
