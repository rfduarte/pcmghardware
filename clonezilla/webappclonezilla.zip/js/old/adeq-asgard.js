$(document).ready(function() {
$("#PageRefresh").click(function() {
$('#spinner').css ('display' , 'inline');
$('#loader').load('bcs/');
});
});
