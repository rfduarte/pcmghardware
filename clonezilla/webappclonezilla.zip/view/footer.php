<footer>
    <div class="footer">
       <div class="container narrow row-fluid">
          <div class="span4"><img src="images/bouton.jpg" style="position:relative;float:left;width:30%;padding:0.5% 1% 0.5% 1%;margin:7px 0 0 0;height:auto;text-align:right" alt="Logo oficial Debian.org">

          </div>
          <div class="span3">

          </div>
          <div class="span5"><img src="images/bouton.jpg"  style="position:relative;float:right;width:30%;padding:0.5% 1%;margin:7px 0px 0px;height:auto;text-align:right;" alt="Logo oficial Debian.org">
                    </div>
       </div>
    </div>
</footer>
</body>

</html>
