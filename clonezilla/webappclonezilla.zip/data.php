<?php

echo date("Y");

?>
