<?php 

require_once "view/header.php";
require_once "view/footer.php";

?>
