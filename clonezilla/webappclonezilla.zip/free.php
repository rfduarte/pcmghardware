<!DOCTYPE html>
<head>
<link rel="stylesheet" href="css/" type="text/css" media="all">
<head>

<?php

sleep(3);
$freeTotal = exec("free -m |awk '/Mem:/{print $2 MB}'");
$freeUtilized = exec("free -m |awk '/Mem:/{print $3 MB}'");
$dfH = exec("df -h | awk {'print $1'}");
$uptime = exec("uptime |awk '{print $3}'");

echo "<b><p>Total memória: $freeTotal</p></b>";
echo	"<b><p>Memória utilizada: $freeUtilized</p><b>";
echo 		"<b><p>Tempo em atividade: $uptime</p><b>";

?>

