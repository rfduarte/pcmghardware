<?php
	class Imagem {
		
		public $path;
				
		function ScanPath() {
						
				$value = array_diff(scandir($this->path) , array('..' , '.'));
		
			foreach ($value as $i => $imagem) {
				$owner = exec("stat -c %U $this->path/$imagem");
				$date = exec("stat -c %y $this->path/$imagem | awk {'print $1'}");
				$perm = exec("stat -c %a $this->path/$imagem");
				$actual_date = exec("date +%F");
				//$size = exec ("sudo du -h $path/$imagem | awk {'print $1'}");
								
				if ( $i % 2 == 0 ) {
					
					$cor = "zebra";
				
			  } else {
				
					$cor = "";
				
				}
											
				echo "<tr class='$cor'>";
				
				if (preg_match("/Asus/i" , "^$imagem")):
					
					echo "<td><img src='images/mb/mb_asus.png'></td>";
				
				elseif (preg_match("/ECS/i" , "^$imagem")):
					
					echo "<td><img src='images/mb/mb_ecs.png'></td>";
				
				elseif (preg_match("/FOXCONN/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_foxconn.jpg'></td>";
				
				elseif (preg_match("/GA/i" , "^$imagem")):
					
					echo "<td><img src='images/mb/mb_gigabyte.png'></td>";
				
				elseif (preg_match("/HP/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_hp.png'></td>";
				
				elseif (preg_match("/Dell/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_dell.png'></td>";
				
				elseif (preg_match("/Intel/i" , "^$imagem")):

					echo "<td><img src='images/mb/mb_intel.png'></td>";
				
				elseif (preg_match("/PCCHIPS/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_pcchips.png'></td>";
				
				elseif (preg_match("/ASROCK/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_asrock.png'></td>";	
				
				elseif (preg_match("/Ln/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_lenovo.png'></td>";
				
				elseif (preg_match("/Lenovo/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_lenovo.png'></td>";
				
				elseif (preg_match("/ITAUTEC/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_itautec.png'></td>";
				
				elseif (preg_match("/ACER/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_acer.png'></td>";
				
				elseif (preg_match("/AOPEN/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_aopen.png'></td>";
				
				elseif (preg_match("/WINFAST/i" , "^$imagem")):
				
					echo "<td><img src='images/mb/mb_winfast.png'></td>";
								
				else:
					
					echo "<td> NULL </td>";
				
				endif;								
					
					echo "<td>";				
					
					if ($perm == 777) {
					
					echo "";
				 }
				
					else {
					
					echo "<a style='text-decoration:none;' title='' data-toggle='tooltip' data-original-title='Imagem bloqueada por permissões. ATUALIZE!' data-placement='top'> <i class='icon-lock'></i></a>"; 
				}	
					
					if ($date == $actual_date) {
				
					echo "<span class='label label-info'>NOVA</span> $imagem";
				
				  } else {
						
					echo "$imagem"; 
					
					}
					
				  echo "</td>";
				  
				  echo "<td> <input type='radio' name='Imagem' value='$imagem' onClick=\"$('#loader').css('display', 'inline'); this.form.submit()\";> </td>"; 
					
				  echo "<td> $date </td><td></td></tr>";
		}
	}
}
?>
